# Changelog

## 0.1.0

- Erstveröffentlichung
- Repo-Installation für `repository.michaz` 5.1 und `repository.thecrew` 0.3.8
- SHA256-Verifikation, sichere Zip-Extraktion und Rollback
- Backup/Restore des Kodi-Profils
- Wartung, Log-Ansicht und Diagnose
- Deutsche und englische Lokalisierung
- Statische Testsuite und reproduzierbarer Build
