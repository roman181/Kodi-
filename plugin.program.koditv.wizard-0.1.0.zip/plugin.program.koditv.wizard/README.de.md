# Kodi DE Wizard

Inoffizielles Community-Addon für Kodi 19+ (Ziel: Kodi 21.3 Omega). Es richtet bekannte Repositories ein, erstellt und sichert Backups und hilft bei der Wartung.

## Installation

1. `plugin.program.koditv.wizard-0.1.0.zip` herunterladen.
2. Kodi → Add-ons → Add-on aus Zip installieren.
3. Addon starten und die Einrichtung verwenden.

## Funktionen

- Einrichtung der Repositories `repository.michaz` 5.1 und `repository.thecrew` 0.3.8
- SHA256-Prüfung der mitgelieferten Repo-Zips
- Sichere Zip-Installation mit Rollback
- Backup des Kodi-Profils (ohne Cache, Temp, Thumbnails und Logs)
- Wiederherstellung von Backups
- Aufräumen von Cache, Temp, Paketen und Vorschaubildern
- Log-Ansicht und Diagnosebericht
- Vollständig deutsch, englischer Fallback

## Wichtig

- Der Wizard kann **Kodi und Android-APKs nicht installieren**. Diese müssen manuell installiert werden.
- Es werden keine Inhalte gehostet. Die Nutzung der Quellen erfolgt auf eigene Verantwortung.
- Keine Adult- oder Wizard-Addons, keine stillen Installationen.
- Nach einer Wiederherstellung muss Kodi neu gestartet werden.
- Ein Backup bei laufendem Kodi kann Datenbanken inkonsistent erfassen. Für ein sauberes Backup Kodi vorher beenden.
- Die Geräteabnahme auf echter Android-TV-Hardware ist noch offen.

## Entwicklung

```bash
python3 tests/run_tests.py
python3 tools/validate.py
```

Der Build erzeugt `dist/plugin.program.koditv.wizard-0.1.0.zip`.

## Lizenz

GPL-3.0-or-later, siehe `LICENSE`.
