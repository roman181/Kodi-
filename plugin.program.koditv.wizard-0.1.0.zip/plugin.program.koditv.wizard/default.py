import os
import sys

ADDON_DIR = os.path.dirname(os.path.abspath(__file__))
LIB_DIR = os.path.join(ADDON_DIR, 'resources', 'lib')
if LIB_DIR not in sys.path:
    sys.path.insert(0, LIB_DIR)

import wizard  # noqa: E402


if __name__ == '__main__':
    wizard.run()
