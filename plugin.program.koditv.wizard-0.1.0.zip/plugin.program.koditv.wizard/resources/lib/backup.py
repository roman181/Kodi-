import json
import os
import shutil
import time
import zipfile

import xbmcaddon
import xbmcgui

from constants import EXCLUDE_DIRS, EXCLUDE_SUFFIXES
from util import human_size, log, msg, translate
from ziptool import ZipValidationError, _safe_member


def userdata_dir():
    return translate('special://userdata')


def _should_skip(path, root, include_logs):
    rel = os.path.relpath(path, root)
    parts = rel.split(os.sep)
    if parts and parts[0] in EXCLUDE_DIRS:
        return True
    if any(part in EXCLUDE_DIRS for part in parts[:-1]):
        return True
    if not include_logs and path.lower().endswith(EXCLUDE_SUFFIXES):
        return True
    return False


def create_backup(destination_dir=None):
    settings = xbmcaddon.Addon()
    destination_dir = destination_dir or translate(settings.getSetting('backup_path') or 'special://home/backups')
    os.makedirs(destination_dir, exist_ok=True)
    stamp = time.strftime('%Y%m%d-%H%M%S')
    target = os.path.join(destination_dir, 'kodi-backup-%s.zip' % stamp)
    root = userdata_dir()
    include_logs = not settings.getSettingBool('backup_exclude_logs')

    files = []
    for current, dirs, names in os.walk(root):
        dirs[:] = [name for name in dirs if not _should_skip(os.path.join(current, name), root, include_logs)]
        for name in names:
            path = os.path.join(current, name)
            if not _should_skip(path, root, include_logs):
                files.append(path)

    progress = xbmcgui.DialogProgress()
    progress.create(msg(30037), target)
    written = 0
    try:
        with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
            manifest = {'addon': 'plugin.program.koditv.wizard', 'created': stamp, 'files': len(files)}
            archive.writestr('koditv-backup.json', json.dumps(manifest, indent=2))
            for index, path in enumerate(files):
                if progress.iscanceled():
                    raise RuntimeError('cancelled')
                archive.write(path, os.path.relpath(path, root))
                written += 1
                progress.update(int(index * 100 / max(len(files), 1)), '%d / %d' % (index + 1, len(files)))
    except Exception:
        progress.close()
        if os.path.isfile(target):
            os.remove(target)
        raise
    progress.close()
    size = os.path.getsize(target)
    log('backup written: %s (%s, %d files)' % (target, human_size(size), written))
    return target, written, size


def list_backups(destination_dir=None):
    settings = xbmcaddon.Addon()
    destination_dir = destination_dir or translate(settings.getSetting('backup_path') or 'special://home/backups')
    if not os.path.isdir(destination_dir):
        return []
    names = [name for name in os.listdir(destination_dir) if name.startswith('kodi-backup-') and name.endswith('.zip')]
    return [os.path.join(destination_dir, name) for name in sorted(names, reverse=True)]


def restore_backup(path):
    if not path or not os.path.isfile(path):
        raise ZipValidationError(msg(30036))
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        if not names or not all(_safe_member(name) for name in names):
            raise ZipValidationError('unsafe backup')
        known = any(name in ('guisettings.xml', 'koditv-backup.json') or name.startswith('addon_data/') for name in names)
        if not known:
            raise ZipValidationError('not a Kodi backup')
        root = userdata_dir()
        for member in archive.infolist():
            target = os.path.join(root, member.filename)
            if not os.path.abspath(target).startswith(os.path.abspath(root) + os.sep):
                raise ZipValidationError('path escape: %s' % member.filename)
            if member.is_dir():
                os.makedirs(target, exist_ok=True)
            else:
                os.makedirs(os.path.dirname(target), exist_ok=True)
                with archive.open(member) as source, open(target, 'wb') as handle:
                    shutil.copyfileobj(source, handle, 1024 * 1024)
    log('backup restored: %s' % path)
    return len(names)
