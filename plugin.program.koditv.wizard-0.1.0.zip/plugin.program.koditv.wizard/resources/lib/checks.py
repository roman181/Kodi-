import shutil

import xbmc

MIN_KODI_VERSION = (19, 0)


def kodi_version():
    version = xbmc.getInfoLabel('System.BuildVersion')
    if not version:
        return (0, 0)
    head = version.split(' ')[0].split('-')[0]
    parts = []
    for piece in head.split('.'):
        digits = ''.join(ch for ch in piece if ch.isdigit())
        if not digits:
            break
        parts.append(int(digits))
    while len(parts) < 2:
        parts.append(0)
    return tuple(parts[:2])


def is_supported():
    return kodi_version() >= MIN_KODI_VERSION


def free_space(path):
    try:
        return shutil.disk_usage(path).free
    except OSError:
        return -1
