import os
import shutil

from util import dir_size, log, translate


def targets():
    return [
        translate('special://temp'),
        translate('special://home/cache'),
        translate('special://home/addons/packages'),
        translate('special://userdata/Thumbnails'),
    ]


def cleanup():
    freed = 0
    for path in targets():
        if not os.path.isdir(path):
            continue
        freed += dir_size(path)
        for name in os.listdir(path):
            child = os.path.join(path, name)
            try:
                if os.path.isdir(child):
                    shutil.rmtree(child, ignore_errors=True)
                else:
                    os.remove(child)
            except OSError:
                pass
    log('cleanup finished, freed %d bytes' % freed)
    return freed
