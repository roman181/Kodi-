ADDON_ID = 'plugin.program.koditv.wizard'

REPOS = [
    {
        'id': 'repository.michaz',
        'file': 'repository.michaz-5.1.zip',
        'version': '5.1',
        'sha256': '0a549491e3467c34b39185d8e3792a4361535312f97a4e2970a2af88770738d1',
        'name_key': 30031,
    },
    {
        'id': 'repository.thecrew',
        'file': 'repository.thecrew-0.3.8.zip',
        'version': '0.3.8',
        'sha256': '686e616ecd7d60906fd7975fe9ccaa09360c8cf0c65ba3431e6d81700b0f6ec0',
        'name_key': 30032,
    },
]

EXCLUDE_DIRS = {
    'cache',
    'temp',
    'thumbnails',
}

EXCLUDE_SUFFIXES = (
    '.log',
    '.log.old',
    '.db-journal',
    '.db-wal',
)
