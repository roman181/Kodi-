import os
import time
import urllib.request

import xbmc
import xbmcgui

from util import human_size, log, msg, sha256_file


def download(url, destination, expected_sha256=None):
    request = urllib.request.Request(url, headers={'User-Agent': 'KodiDEWizard/0.1'})
    progress = xbmcgui.DialogProgress()
    progress.create(msg(30040), url)
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            total = int(response.headers.get('Content-Length') or 0)
            os.makedirs(os.path.dirname(destination), exist_ok=True)
            received = 0
            with open(destination, 'wb') as handle:
                while True:
                    if progress.iscanceled():
                        raise RuntimeError('cancelled')
                    chunk = response.read(256 * 1024)
                    if not chunk:
                        break
                    handle.write(chunk)
                    received += len(chunk)
                    if total:
                        progress.update(int(received * 100 / total), '%s / %s' % (human_size(received), human_size(total)))
            if total and received != total:
                raise RuntimeError('incomplete download')
    finally:
        progress.close()
    if expected_sha256:
        actual = sha256_file(destination)
        if actual.lower() != expected_sha256.lower():
            os.remove(destination)
            raise RuntimeError(msg(30026))
    log('downloaded %s (%s)' % (url, human_size(os.path.getsize(destination))))
    return destination


def download_with_retry(url, destination, expected_sha256=None, attempts=3):
    last = None
    for attempt in range(1, attempts + 1):
        try:
            return download(url, destination, expected_sha256)
        except Exception as exc:
            last = exc
            log('download attempt %d failed: %s' % (attempt, exc), xbmc.LOGWARNING)
            time.sleep(2 * attempt)
    raise last
