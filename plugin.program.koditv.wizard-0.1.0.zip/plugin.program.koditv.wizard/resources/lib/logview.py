import os

import xbmc
import xbmcaddon

from checks import free_space, kodi_version
from constants import ADDON_ID, REPOS
from repos import status
from util import human_size, msg, translate


def tail_log(lines=300):
    path = os.path.join(translate('special://logpath'), 'kodi.log')
    if not os.path.isfile(path):
        return None
    with open(path, 'r', encoding='utf-8', errors='replace') as handle:
        content = handle.readlines()
    return ''.join(content[-lines:])


def diagnostics():
    addon = xbmcaddon.Addon()
    lines = [
        'Kodi DE Wizard %s' % addon.getAddonInfo('version'),
        'Kodi: %s' % '.'.join(str(part) for part in kodi_version()),
        'System: %s' % xbmc.getInfoLabel('System.OSVersionInfo'),
        'Addon-ID: %s' % ADDON_ID,
        'Userdata: %s' % translate('special://userdata'),
        'Freier Speicher: %s' % human_size(max(free_space(translate('special://home')), 0)),
        '',
        msg(30051) + ':',
    ]
    for repo in REPOS:
        state, version = status(repo)
        lines.append('  %s: %s %s' % (repo['id'], state, version or ''))
    return '\n'.join(lines)
