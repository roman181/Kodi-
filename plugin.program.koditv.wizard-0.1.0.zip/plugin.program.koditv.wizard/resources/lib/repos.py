import os
import shutil

import xbmc
import xbmcaddon
import xbmcvfs

from util import data_path, log, msg, sha256_file, translate
from ziptool import ZipValidationError, safe_extract, validate_addon_zip


def addons_dir():
    return translate('special://home/addons')


def repo_path(repo):
    return os.path.join(addons_dir(), repo['id'])


def installed_version(repo):
    manifest = os.path.join(repo_path(repo), 'addon.xml')
    if not os.path.isfile(manifest):
        return None
    try:
        import xml.etree.ElementTree as ET
        return ET.parse(manifest).getroot().get('version')
    except ET.ParseError:
        return None


def status(repo):
    version = installed_version(repo)
    if version is None:
        return 'missing', None
    return 'installed', version


def _verify_source(repo):
    source = data_path(repo['file'])
    if not os.path.isfile(source):
        raise RuntimeError('%s: %s' % (msg(30027), repo['file']))
    if xbmcaddon.Addon().getSettingBool('verify_hashes'):
        actual = sha256_file(source)
        if actual.lower() != repo['sha256'].lower():
            raise RuntimeError('%s: %s' % (msg(30026), repo['file']))
    return source


def install(repo, force=False):
    source = _verify_source(repo)
    info = validate_addon_zip(source, repo['id'], repo['version'])
    target = repo_path(repo)
    current = installed_version(repo)
    if current == repo['version'] and not force:
        return 'already'

    staging = os.path.join(addons_dir(), '.koditv-staging')
    shutil.rmtree(staging, ignore_errors=True)
    os.makedirs(staging, exist_ok=True)
    safe_extract(source, staging)
    staged = os.path.join(staging, info['root'])
    if not os.path.isdir(staged):
        raise ZipValidationError('missing root %s' % info['root'])

    backup = target + '.bak'
    shutil.rmtree(backup, ignore_errors=True)
    try:
        if os.path.isdir(target):
            os.rename(target, backup)
        os.rename(staged, target)
        xbmc.executebuiltin('UpdateLocalAddons')
        xbmc.sleep(800)
        xbmc.executebuiltin('EnableAddon(%s)' % repo['id'])
        shutil.rmtree(backup, ignore_errors=True)
        log('installed %s %s' % (repo['id'], info['version']))
        return 'installed'
    except Exception:
        shutil.rmtree(target, ignore_errors=True)
        if os.path.isdir(backup):
            os.rename(backup, target)
        raise
    finally:
        shutil.rmtree(staging, ignore_errors=True)


def uninstall(repo):
    xbmc.executebuiltin('DisableAddon(%s)' % repo['id'])
    shutil.rmtree(repo_path(repo), ignore_errors=True)
    xbmc.executebuiltin('UpdateLocalAddons')
    log('uninstalled %s' % repo['id'])


def install_many(repos, force=False, progress=None):
    results = []
    for index, repo in enumerate(repos):
        if progress:
            progress(index, len(repos), repo['id'])
        try:
            results.append((repo['id'], install(repo, force=force)))
        except Exception as exc:
            log('install failed %s: %s' % (repo['id'], exc), xbmc.LOGERROR)
            results.append((repo['id'], 'error: %s' % exc))
    return results
