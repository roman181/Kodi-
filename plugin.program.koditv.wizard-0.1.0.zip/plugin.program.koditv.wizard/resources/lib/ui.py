import xbmcaddon
import xbmcgui

from util import msg


def select(heading, items):
    return xbmcgui.Dialog().select(heading, items)


def multiselect(heading, items, preselect=None):
    return xbmcgui.Dialog().multiselect(heading, items, preselect=preselect or [])


def progress(heading):
    dialog = xbmcgui.DialogProgress()
    dialog.create(heading)
    return dialog


def select_backup(paths):
    if not paths:
        return None
    labels = [path.rsplit('/', 1)[-1].rsplit('\\', 1)[-1] for path in paths]
    index = select(msg(30005), labels)
    return None if index < 0 else paths[index]
