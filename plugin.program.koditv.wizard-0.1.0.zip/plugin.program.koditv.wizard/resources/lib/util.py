import hashlib
import os

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon()


def msg(text_id):
    return ADDON.getLocalizedString(text_id)


def log(message, level=xbmc.LOGINFO):
    xbmc.log('[%s] %s' % (ADDON.getAddonInfo('id'), message), level)


def translate(path):
    return xbmcvfs.translatePath(path)


def addon_path():
    return translate(ADDON.getAddonInfo('path'))


def data_path(filename):
    return os.path.join(addon_path(), 'resources', 'data', filename)


def sha256_file(path):
    digest = hashlib.sha256()
    with open(path, 'rb') as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def human_size(num):
    size = float(num)
    for unit in ('B', 'KB', 'MB', 'GB'):
        if size < 1024.0 or unit == 'GB':
            return '%.1f %s' % (size, unit)
        size /= 1024.0
    return '%.1f GB' % size


def dir_size(path):
    total = 0
    for root, _dirs, files in os.walk(path):
        for name in files:
            try:
                total += os.path.getsize(os.path.join(root, name))
            except OSError:
                pass
    return total


def notify(message, icon=xbmcgui.NOTIFICATION_INFO, time=4000):
    xbmcgui.Dialog().notification(ADDON.getAddonInfo('name'), message, icon, time)


def info(message):
    xbmcgui.Dialog().ok(ADDON.getAddonInfo('name'), message)


def error(message):
    xbmcgui.Dialog().ok(ADDON.getAddonInfo('name'), message)
    log(message, xbmc.LOGERROR)


def confirm(message):
    return xbmcgui.Dialog().yesno(ADDON.getAddonInfo('name'), message)


def textviewer(heading, text):
    xbmcgui.Dialog().textviewer(heading, text)
