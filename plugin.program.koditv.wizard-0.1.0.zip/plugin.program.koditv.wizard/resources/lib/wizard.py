import xbmc
import xbmcaddon

import backup
import checks
import cleanup
import logview
import repos
import ui
from constants import REPOS
from util import confirm, error, human_size, info, log, msg, notify, textviewer, translate

ADDON = xbmcaddon.Addon()


def _repo_labels():
    labels = []
    for repo in REPOS:
        state, version = repos.status(repo)
        if state == 'installed':
            labels.append('[%s] %s (%s)' % (msg(30052), repo['id'], version))
        else:
            labels.append('[ ] %s' % repo['id'])
    return labels


def _summary(results):
    lines = []
    for repo_id, outcome in results:
        if outcome == 'installed':
            lines.append('%s: %s' % (repo_id, msg(30018)))
        elif outcome == 'already':
            lines.append('%s: %s' % (repo_id, msg(30017)))
        else:
            lines.append('%s: %s' % (repo_id, outcome))
    return '\n'.join(lines)


def setup_flow():
    if not checks.is_supported():
        info(msg(30015))
        return
    free = checks.free_space(translate('special://home'))
    if 0 <= free < 200 * 1024 * 1024:
        if not confirm(msg(30047) + ': ' + human_size(free) + '\n\n' + msg(30085)):
            return
    selected = ui.multiselect(msg(30033), _repo_labels(), list(range(len(REPOS))))
    if not selected:
        return
    chosen = [REPOS[index] for index in selected]
    names = '\n'.join(repo['id'] for repo in chosen)
    if not confirm(names + '\n\n' + msg(30085)):
        return
    dialog = ui.progress(msg(30052))

    def report(index, total, repo_id):
        if dialog.iscanceled():
            raise RuntimeError(msg(30029))
        dialog.update(int(index * 100 / max(total, 1)), repo_id)

    try:
        results = repos.install_many(chosen, progress=report)
    finally:
        dialog.close()
    info(_summary(results))
    notify(msg(30018))
    if confirm(msg(30004) + '\n\n' + msg(30085)):
        create_backup_flow()


def repo_flow():
    items = [msg(30052), msg(30054), msg(30051)]
    choice = ui.select(msg(30003), items)
    if choice == 0:
        setup_flow()
    elif choice == 1:
        selected = ui.multiselect(msg(30054), _repo_labels(), list(range(len(REPOS))))
        if selected and confirm(msg(30054) + '\n\n' + msg(30085)):
            for index in selected:
                repos.uninstall(REPOS[index])
            notify(msg(30054))
    elif choice == 2:
        textviewer(msg(30051), '\n'.join(_repo_labels()))


def create_backup_flow():
    if not confirm(msg(30037) + '\n\n' + msg(30085)):
        return
    try:
        path, count, size = backup.create_backup()
    except Exception as exc:
        error('%s: %s' % (msg(30014), exc))
        return
    info('%s\n\n%s\n%d Dateien, %s' % (msg(30020), path, count, human_size(size)))


def restore_flow():
    paths = backup.list_backups()
    path = ui.select_backup(paths)
    if not path:
        return
    if not confirm(msg(30021) + '\n\n' + msg(30022)):
        return
    try:
        count = backup.restore_backup(path)
    except Exception as exc:
        error('%s: %s' % (msg(30014), exc))
        return
    info('%s\n%d Einträge\n\n%s' % (msg(30038), count, msg(30022)))


def cleanup_flow():
    if not confirm(msg(30041) + '\n\n' + msg(30085)):
        return
    freed = cleanup.cleanup()
    info('%s\n%s' % (msg(30023), human_size(freed)))


def log_flow():
    choice = ui.select(msg(30007), [msg(30055), msg(30035)])
    if choice == 0:
        content = logview.tail_log()
        textviewer(msg(30055), content or msg(30025))
    elif choice == 1:
        textviewer(msg(30035), logview.diagnostics())


def info_flow():
    textviewer(msg(30009), msg(30043))


def main_menu():
    items = [
        '1  ' + msg(30002),
        '2  ' + msg(30003),
        '3  ' + msg(30004),
        '4  ' + msg(30005),
        '5  ' + msg(30006),
        '6  ' + msg(30007),
        '7  ' + msg(30008),
        '8  ' + msg(30009),
        '0  ' + msg(30010),
    ]
    return ui.select(ADDON.getAddonInfo('name'), items)


def run():
    log('wizard started')
    if ADDON.getSettingBool('show_disclaimer'):
        if not confirm(msg(30016)):
            return
    while True:
        try:
            choice = main_menu()
            if choice < 0 or choice == 8:
                break
            if choice == 0:
                setup_flow()
            elif choice == 1:
                repo_flow()
            elif choice == 2:
                create_backup_flow()
            elif choice == 3:
                restore_flow()
            elif choice == 4:
                cleanup_flow()
            elif choice == 5:
                log_flow()
            elif choice == 6:
                ADDON.openSettings()
            elif choice == 7:
                info_flow()
        except Exception as exc:
            log('unhandled error: %s' % exc, xbmc.LOGERROR)
            error('%s: %s' % (msg(30014), exc))
    log('wizard stopped')
