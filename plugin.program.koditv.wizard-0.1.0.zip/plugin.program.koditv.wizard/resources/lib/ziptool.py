import os
import zipfile

import xml.etree.ElementTree as ET


class ZipValidationError(Exception):
    pass


def _safe_member(name):
    if not name or name.startswith('/') or name.startswith('\\'):
        return False
    parts = name.replace('\\', '/').split('/')
    return '..' not in parts


def validate_addon_zip(path, expected_id=None, expected_version=None):
    if not os.path.isfile(path):
        raise ZipValidationError('missing file: %s' % path)
    try:
        with zipfile.ZipFile(path) as archive:
            bad = archive.testzip()
            if bad:
                raise ZipValidationError('corrupt member: %s' % bad)
            names = archive.namelist()
            if not names or not all(_safe_member(name) for name in names):
                raise ZipValidationError('unsafe member names')
            manifest = None
            for name in names:
                if name.count('/') == 1 and name.endswith('/addon.xml'):
                    manifest = name
                    break
            if not manifest:
                raise ZipValidationError('addon.xml not found')
            root = ET.fromstring(archive.read(manifest))
            addon_id = root.get('id')
            version = root.get('version')
            if expected_id and addon_id != expected_id:
                raise ZipValidationError('id mismatch: %s' % addon_id)
            if expected_version and version != expected_version:
                raise ZipValidationError('version mismatch: %s' % version)
            return {'id': addon_id, 'version': version, 'root': manifest.split('/')[0]}
    except zipfile.BadZipFile as exc:
        raise ZipValidationError(str(exc))


def safe_extract(path, destination):
    os.makedirs(destination, exist_ok=True)
    with zipfile.ZipFile(path) as archive:
        for member in archive.infolist():
            if not _safe_member(member.filename):
                raise ZipValidationError('unsafe member: %s' % member.filename)
            if (member.external_attr >> 16) & 0o170000 == 0o120000:
                raise ZipValidationError('symlink member: %s' % member.filename)
            target = os.path.join(destination, member.filename)
            if not os.path.abspath(target).startswith(os.path.abspath(destination) + os.sep):
                raise ZipValidationError('path escape: %s' % member.filename)
        archive.extractall(destination)
